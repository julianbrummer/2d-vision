Anmerkung:
Bei der Ausgabe gibt es noch ein paar kleine Problemchen, welche ich selber noch nicht gefunden habe.
Die Textur wird ohne große Probleme angezeigt (ich hoffe auch, dass das richtig ist). 
Beim Denoised Image wird nur ein weißes Bild angezeigt.