ReadMe fuer Aufgabe 1:

Script einfach ausfuehren. Esc beendet die Anwendung.